
package tubes;

/**
 *
 * @author Lintang Nurcahyo
 */
public interface Login {
    void login(String username, String password);
    void Logout(String username, String password);
}