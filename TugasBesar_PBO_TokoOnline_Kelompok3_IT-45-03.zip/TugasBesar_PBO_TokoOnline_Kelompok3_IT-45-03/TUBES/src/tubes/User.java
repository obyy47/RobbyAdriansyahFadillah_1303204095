
package tubes;

/**
 *
 * @author Lintang Nurcahyo
 */
public class User extends Akun{
    private String email;
    private String alamat;
    private String nomorHandphone;

    public User(String email, String alamat, String nomorHandphone, String username, String password){
        super(username, password);
        this.email = email;
        this.alamat = alamat;
        this.nomorHandphone = nomorHandphone;
    }
    
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAlamat() {
        return alamat;
    }

    public void setAlamat(String alamat) {
        this.alamat = alamat;
    }

    public String getNomorHandphone() {
        return nomorHandphone;
    }

    public void setNomorHandphone(String nomorHandphone) {
        this.nomorHandphone = nomorHandphone;
    }
   
}